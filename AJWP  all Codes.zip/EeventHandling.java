package com.sample.com;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class EeventHandling implements ActionListener{
	JFrame jf;
	JButton b1;
	 JLabel jlb;
	int counter=0;
	
	EeventHandling()
	{
		JFrame jf=new JFrame("Counter Application");
		jf.setSize(300,300);
		jf.setLayout(null);
		
		//
		JButton b1= new JButton("Click me");
		b1.setBounds(40,10,100,20);
		
		Color c=new Color(204,204,255);
		b1.setBackground(c);
		
		
		//
		this.jlb=new JLabel("Count 0");
		jlb.setBounds(150,10,100,20);
		b1.addActionListener(this);
		
		//
		jf.add(b1);
		jf.add(jlb);
		jf.setVisible(true);
		
	}
	//
	public void actionPerformed(ActionEvent e)
	{
		counter++;
		jlb.setText("Count :"+counter);
	}
	

	public static void main(String[] args) {
		//EeventHandling evh=new EeventHandling();
		new EeventHandling();

	}
	
	
}
