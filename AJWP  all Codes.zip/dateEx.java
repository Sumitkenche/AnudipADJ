package com.sample.com;
import java.time.*;
public class dateEx {

	public static void main(String[] args) {
		/*LocalDate ld=LocalDate.now();
		LocalTime t=LocalTime.now();
		System.out.println(ld);
		System.out.println("Day of "+ld.getMonth()+" "+ld.getDayOfMonth());
		System.out.println("\nOrder date is:"+ld.minusDays(15));
		System.out.println("\nReplace till:"+ld.plusDays(15));
		System.out.println("\nCurrent time is:"+t);
		System.out.println("\nHours is :"+t.getHour()+" \nminute is: "+t.getMinute()+" \nseconds are :"+t.getSecond()+"\nNanoseconds are :"+t.getNano());
		
		*/

		LocalDateTime tdt=LocalDateTime.now();
		System.out.println(tdt);
		
		System.out.println(tdt.getDayOfYear());
		
		ZonedDateTime zdt= ZonedDateTime.now();
		System.out.println("Zonal Date And Time is:"+zdt);
		
	}

}
