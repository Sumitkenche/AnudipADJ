package com.sample.com;
import java.time.*;
import java.time.format.DateTimeFormatter;
public class dateformat {

	public static void main(String[] args) {
		
	LocalDateTime ldt=LocalDateTime.now();
	
	System.out.println(" current Date and time is: "+ldt);
	
	DateTimeFormatter formatter=DateTimeFormatter.ofPattern("(DD/MM/YY) (HH:MM:SS)");
   
    String formatted=ldt.format(formatter);

    System.out.println("Formatted date and time is --> " + formatted);
	}

}
