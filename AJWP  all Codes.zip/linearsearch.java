package com.sample.com;

import java.util.Arrays;
import java.util.Scanner;
public class linearsearch {
	public static void main(String args[])
	{
					
				Scanner sc=new  Scanner(System.in);
				
				 System.out.println("Enter size of an Array");
				 int size=sc.nextInt();
				 int numbers[]=new int[size];
				 
				 System.out.println("Enter elements in Array");
				 
				 for(int i=0;i<size;i++)
				 {
				   int a=sc.nextInt();
				 }
				 System.out.println("Array is:::"+numbers[size]);
				 
				 
	}

}
