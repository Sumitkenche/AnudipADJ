package com.sample.com;
@FunctionalInterface
interface StringOperation {
    String operate(String s);
}


public class Lambda_stringManipulation {

    public static void main(String[] args) {

        String str = "Kenche Sumit";

        StringOperation toUpper = ( String s) -> s.toUpperCase();
        
        StringOperation toLower = (String s) -> s.toLowerCase();

        StringOperation reverse = (String s) -> {
            String rev = "";
            
            for (int i = s.length() - 1; i >= 0; i--) 
            {
                rev =rev + s.charAt(i);
            }
            return rev;
        };

       
        System.out.println("Original   : " + str);
        System.out.println("Uppercase  : " + toUpper.operate(str));
        System.out.println("Lowercase  : " + toLower.operate(str));
        System.out.println("Reverse    : " + reverse.operate(str));
    }
}
