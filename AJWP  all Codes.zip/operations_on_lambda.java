package com.sample.com;

@FunctionalInterface
interface Arithmats{
	int calculate(int a,int b);
}



public class operations_on_lambda {

	public static void main(String[] args) {
		int x=10;
		int y=5;
		
		Arithmats add=(a,b)-> a + b;
		Arithmats sub=(a,b)->a-b;
		Arithmats mul=(a,b)->a*b;
		Arithmats div=(a,b)->a/b;
		System.out.println("Addition      :"+add.calculate(x,y));
		System.out.println("Substraction  :"+sub.calculate(x, y));
		System.out.println("Multiplication:"+mul.calculate(x,y));
		System.out.println("Division      :"+div.calculate(x, y));
			
		
	}

}
