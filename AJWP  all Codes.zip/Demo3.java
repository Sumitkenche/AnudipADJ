package com.sample.com;

import java.awt.Color;
import javax.swing.*;
import java.awt.event.*;

public class Demo3 implements ActionListener {

    private JButton jb;
    private JTextField jtf;

    Demo3() {
        JFrame jf = new JFrame();
        jf.setSize(400, 400);
        jf.setLayout(null);

        this.jb = new JButton("Click");   
        
        jb.setBackground(Color.CYAN);
        jb.setForeground(Color.BLACK);
        jb.addActionListener(this);

        this.jtf = new JTextField();    
        
        JLabel lb = new JLabel("This is label");
        lb.setBounds(70, 20, 100, 20);
        jtf.setBounds(45, 50, 120, 30);
        jb.setBounds(50, 100, 100, 30);


        jf.add(jtf);
        jf.add(jb);
        jf.add(lb);

        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String args[]) {
        new Demo3();
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
    	   
        String a = jtf.getText();
        int num=Integer.parseInt(a);
        
        
        System.out.println(num+10);
    	/*if(e.getSource()==jb)
    	{
    		System.out.println("CLICKEDDDDDDDDDDDDDD");
    	}else {
    		System.out.println("ANother action performed");
    	}*/
    	
    }
}
