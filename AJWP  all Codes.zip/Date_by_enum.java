package com.sample.com;
import java.time.Month;

public class Date_by_enum {

    public static void main(String[] args) {

        Month m = Month.JANUARY;

        for (int i = 1; i <= 12; i++) {

            System.out.println(m + " : " + m.length(false) + " days");

            m = m.plus(1); 
        }
    }
}
