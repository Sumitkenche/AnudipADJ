package com.sample.com;
import java.util.HashSet;
public class Lab_2_Set {

	public static void main(String[] args) 
	{
		HashSet <Integer> hs=new HashSet();
		
		hs.add(5);
		hs.add(10);
		hs.add(15);
		hs.add(20);
		hs.add(25);
		
		
		System.out.println("Elements in hash set:----"+hs);
		System.out.println("_____________________________________________");
		
		
		if(hs.contains(10))
		{
			System.out.println("Number 10 is present is set ");
			
		}else
		{
			System.out.println("Numberr is not present in set");
		}
		System.out.println("_____________________________________________");
		
		System.out.println("Set before removing 15:----"+hs);
		hs.remove(15);	
		System.out.println("*********");
		System.out.println("set after removing 15:----"+hs);
		System.out.println("_____________________________________________");
		
		System.out.println("Finalli size of set Would be:----"+hs.size());
		
		

	}

}
