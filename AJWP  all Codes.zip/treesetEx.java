package com.sample.com;
import java.util.TreeSet;
public class treesetEx {

	public static void main(String[] args) {
	
   TreeSet <Integer> ts=new TreeSet();
   
   ts.add(55);
   ts.add(22);
   ts.add(11);
   ts.add(22);
   ts.add(77);
   //ts.add("Aman");
   
   
   System.out.println("Treeset elements are:----"+ts);

	if(ts.contains(11))
	{
		System.out.println("Number 11 is present is set ");
		
	}else
	{
		System.out.println("Numberr is not present in set");
	}
	System.out.println("_____________________________________________");
	
	System.out.println("Set before removing 22:----"+ts);
	ts.remove(22);	
	System.out.println("*********");
	System.out.println("set after removing 22:----"+ts);
	System.out.println("_____________________________________________");
	
	System.out.println("Finalli size of set Would be:----"+ts.size());
	
	

   
   
	}

}
