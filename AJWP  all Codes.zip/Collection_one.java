package com.sample.com;
import java.util.ArrayList;
import java.util.Scanner;
public class Collection_one {

	public static void main(String[] args) {
		ArrayList<Integer> al=new ArrayList<Integer>();
		
		
				
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.add(5);
		al.add(6);
		al.add(7);
		
		int sum=0;
		
		for(int i=0;i<al.size();i++)
		{
			int a= al.get(i);
			
			if(a%2==0)
			{
				sum=sum+a;
				
			}
		}
		System.out.println(sum);
		

	}

}
