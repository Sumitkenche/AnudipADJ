package com.sample.com;

public class Sumit {
   public void m()
   {
	   System.out.println("hello");
   }
}
