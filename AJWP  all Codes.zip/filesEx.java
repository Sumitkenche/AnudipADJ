package com.sample.com;
import java.io.*;
public class filesEx {

	public static void main(String[] args) throws IOException
	{
	File f=new File("C:\\Users\\Sumit\\Downloads\\abc.txt");//F points to existing files ,dnt creatw new file
	System.out.println(f.exists());
	
	
	f.createNewFile();
	
	System.out.println("Absolute Path: " + f.getAbsolutePath());
	System.out.println("Canonical Path: " + f.getCanonicalPath());
    System.out.println("Parent Directory: " + f.getParent());
    System.out.println("File Name: " + f.getName());

    
    
    FileWriter fw=new FileWriter("C:\\Users\\Sumit\\Downloads\\abc.txt");
    
    
    
    fw.write("\nSumit kenche");
    fw.write("\n File is written for the first time\n");
    
    //char[] ch= {'a'};
    //fw.write(ch);
    //fw.flush();
    fw.close();
    System.out.println("Written successfullly........");
    
    
	}

}
