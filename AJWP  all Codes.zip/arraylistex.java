package com.sample.com;
import java.util.ArrayList;
public class arraylistex {

	public static void main(String[] args) {
		//insertion Order is preserved in ArrayList
		// Null insertion is possible 
		//Duplicates are Allowed
		// Al can be specific for data types and can be generic
		// While insertion at specific index it gives problem then we prefer linked list
		//best for retrieval
		//fixed size 10 after that it makes copy of it
		 // Linked list is best for insertion but while retrieval we need to traverse whole linked list
		ArrayList <String> al=new ArrayList <String>();
		al.add("Sumit");
		al.add("Rushi");
		al.add("Vaibhav");
		//al.add(1);is ArrayList al=new ArrayList();
		al.add(null);
		System.out.println(al.size());
		System.out.println(al);
		al.remove("Vaibhav");
		System.out.println(al.size());
		System.out.println(al);
		al.remove(1);
		System.out.println(al);
		
		al.set(0, "Pankaj");
		System.out.println(al);
		
		System.out.println(al.get(0));
	}

}
