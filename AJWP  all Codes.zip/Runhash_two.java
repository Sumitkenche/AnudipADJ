package com.sample.com;

import java.util.HashMap;

 class Students_One {
	 int id;
	String name ;
	
	
	public Students_One(int id,String name)
	{
		this.name=name;
		this.id=id;
		
	}
	@Override
	public String toString(){
		return "\nid: "+id +" name :"+ name +"";
	}

}
 
 

public class Runhash_two {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students_One s1=new Students_One(18,"Virat");
		
		Students_One s2=new Students_One(45,"Rohit");
		
		
		HashMap<Integer,Students_One> hm=new HashMap<Integer,Students_One>();
		
		hm.put(1,s1);
		hm.put(2,s2);
		System.out.println(" MAP :"+hm);
		
		

	}
	
	
}

