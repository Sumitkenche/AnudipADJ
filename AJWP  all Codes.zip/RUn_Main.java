package com.sample.com;

public class RUn_Main {

	public static void main(String[] args) {
		Rushi s=new Rushi();
		s.show();

	}

}
