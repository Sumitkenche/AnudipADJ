package com.sample.com;


public class Bankexc extends RuntimeException
{
	public Bankexc(String s)
	{
		super(s);
	}

}
