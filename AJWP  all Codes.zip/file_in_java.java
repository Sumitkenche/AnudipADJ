package com.sample.com;
import java.io.*;
public class file_in_java {

	public static void main(String[] args)throws IOException
	{
		// TODO Auto-generated method stub
  File f=new File("C:\\\\Users\\\\Sumit\\\\Downloads\\\\abc.txt");
  
  FileReader fr=new FileReader(f);
   
  int ch=0;
  int count=0;
  while((ch=fr.read()) !=-1)
  {
	  System.out.print((char) ch);
	  count++;
  }
  
  System.out.println("***Total number of character is ***:"+count);
  fr.close();
	}

}