package com.sample.com;

import java.util.Arrays;

public class Bubblesort {

	public static void main(String[] args) {
		int arr[]= {10,9,11,6};
		
		System.out.println("Main array"+Arrays.toString(arr));
		int[] otherarray=Arrays.copyOf(arr, arr.length);
		
		Arrays.sort(otherarray);
		System.out.println(" initial Sorted array is:"+Arrays.toString(otherarray));
		
		for(int i=0;i<=arr.length-1;i++)//range
		{
			for(int j=0;j<arr.length-1-i;j++) {//pointer
				
				if(arr[j]>arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		
		System.out.println("sorted Result by bubble sort is :"+Arrays.toString(arr));
	}
}
		
					
				
				
				
				
				
				

