package com.sample.com;
@FunctionalInterface
public interface lambdaif {
	void m1(String c);
}
