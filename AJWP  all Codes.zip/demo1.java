package com.sample.com;

public class demo1 {
	int amount= 900;
	int withdraw=907;
	
	public void m1()
	{
		if(amount<withdraw)
		{
			throw new Bank("Insufficient funs");//Bank excecption Object created ,CONSTRUCTOR RUNS bank is a custom unchekcked eception
		}
		else {
			System.out.println("Successfully");
		}
	}

}
