package com.sample.com;
import java.util.HashSet;




 class Runhash  {

	public static void main(String[] args) {
		
		 Students s1=new Students(101,"sumit");
		 Students s2=new Students(102,"Amit");
		 Students s3=new Students(103,"harish");
		 Students s4=new Students(104,"aryan");
		 Students s5=new Students(105,"abhi");
		 
		HashSet<Students> hs=new HashSet<Students>();
		
		hs.add(s1);
		hs.add(s2);
		hs.add(s3);
		hs.add(s4);
		hs.add(s5);
		System.out.println(hs);

	}

	


}
