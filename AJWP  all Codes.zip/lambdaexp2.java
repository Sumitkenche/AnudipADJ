package com.sample.com;

public class lambdaexp2 {

	public static void main(String[] args) {
		lambdaif li=(String  c)->{
			System.out.println("lambda interface implementation by :"+ c);
		                };
		
		li.m1("Sumit");
	}

}
