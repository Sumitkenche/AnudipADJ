package com.sample.com;

public class Rushi {
   Sumit d=new Sumit();
   public void show()
   {
	   d.m();
   }
}
