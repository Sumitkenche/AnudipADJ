
package com.sample.com;
import java.util.ArrayList;
public class Collection_two {
    public static void main(String[] args) {

        ArrayList<String> l = new ArrayList<>();


        l.add("Apple");
        l.add("Ball");
        l.add("Cat");
        l.add("Dog");

        System.out.println("Main List "+ l);

       
        ArrayList<String> rl = new ArrayList<>();

        
        for (int i = l.size() - 1; i >= 0; i--) {
            rl.add(l.get(i));
        }
        System.out.println("Reversed List "+ rl);

    }
}
