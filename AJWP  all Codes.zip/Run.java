package com.sample.com;
//import java.util.Scanner;
public class Run {

	public static void main(String[] args) {
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Balance Amount");
		int amount=sc.nextInt();
		System.out.println("Enter Withdraw amount");
		int withdraw=sc.nextInt();
		*/
		demo1 d1=new demo1();
		d1.m1();

	}

}
