package com.sample.com;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class fileexc {

	public static void main(String[] args)throws FileNotFoundException
		{
			FileReader f=new FileReader("abc.txt");
		}
}
	
		

	


