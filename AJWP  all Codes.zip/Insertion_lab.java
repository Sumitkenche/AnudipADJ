package com.sample.com;

import java.util.Scanner;

public class Insertion_lab {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        
        System.out.print("Enter number of strings you want to add : ");
        int size = sc.nextInt();
        
        sc.nextLine(); 
        
        String[] arr = new String[size];

        System.out.println("Enter the strings:");
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextLine();
        }

     
        for (int i = 1; i < size; i++) {
            String key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j].compareTo(key) > 0) {
                arr[j + 1] = arr[j];
                j--;
            }

            arr[j + 1] = key;
        }

       
        System.out.println("Sorted string");
        for (int i = 0; i < size; i++) {
            System.out.println(arr[i]);
        }

        sc.close();
    }
}
