package com.sample.com;

class Students {
	int id;
	String name;
	
	public Students(int id,String name) 
	{
		this.id=id;
		this.name=name;
	}
	//toString() method of parent class of a class (i.e object class)
	@Override
	public String toString(){
		return "\nid: "+ id +" name :"+ name +"";
	}

	

}
