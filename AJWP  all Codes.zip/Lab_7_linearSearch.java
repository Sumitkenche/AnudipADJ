package com.sample.com;
import java.util.Arrays;
import java.util.Scanner;
public class Lab_7_linearSearch {

	public static void main(String[] args)
	{
		Scanner sc=new  Scanner(System.in);
		
		int arr[]= {10,6,22,66,99};
		
	
	System.out.println("Enter element to search from :"+Arrays.toString(arr));
	
	int x=sc.nextInt();
	
	for(int i=0;i<=arr.length-1;i++)
	{
		if(arr[i]==x)
		{
			
			System.out.println("Element Found At Index : "+i);
		}else
		{
			System.out.println("Element is not in array");
			return;
		}
	}
		

	}

}
