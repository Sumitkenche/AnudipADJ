package com.sample.com;
//import java.util.Scanner;

class BankAccount {
    int balance = 50;

    void deposit(int amount) {
        balance = balance + amount;
        System.out.println("Balance after deposit: " + balance);
    }

    void withdraw(int amount){
    	
    	if (amount > balance)
    	   {
                throw new Bankexc ("Insufficient balance");
            }else {
            balance = balance - amount;
            System.out.println("Balance after withdrawal: " + balance);
    
            }    
    }
}