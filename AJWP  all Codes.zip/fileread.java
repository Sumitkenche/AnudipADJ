package com.sample.com;
import java.io.*;
public class fileread {

	public static void main(String[] args)throws IOException
	{
		// TODO Auto-generated method stub
  File f=new File("C:\\\\Users\\\\Sumit\\\\Downloads\\\\abc.txt");
  
  FileReader fr=new FileReader(f);
  char ch[]=new char[(int) f.length()];
  
  fr.read(ch);
  
  for (char x:ch)
  {
	  System.out.print(x);
  }
 /* for(int i=0;i<ch.length;i++)
  {
	  System.out.print(ch[i]);
  }
  */
  System.out.println("Red successfully");
  
  
	}

}
