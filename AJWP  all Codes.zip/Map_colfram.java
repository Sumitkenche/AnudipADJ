package com.sample.com;

import java.util.HashMap;



//map have values in key:value pairs
//key are unique 
//values are duplicate
// value added in map using put()
// one one null key allowed
//hash code is based on key data

public class Map_colfram {

	public static void main(String[] args) {
		HashMap<Integer,String> hm=new HashMap<>();

		hm.put(101, "Sumit");
		hm.put(102, "Rushi");
		hm.put(105, "tushar");
		hm.put(103, "sushant");
		hm.put(104, "yogesh");
		
		System.out.println(hm);
	boolean tr=hm.containsKey(102);
	System.out.println(tr);
	System.out.println(hm.get(103));
			
		
		
	}

}
