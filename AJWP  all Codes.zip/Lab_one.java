package com.sample.com;
import java.util.Scanner; 
public class Lab_one {

	
		public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);
	        BankAccount ba = new BankAccount();

	        System.out.println("Enter Deposit:");
	        int a = sc.nextInt();
	        ba.deposit(a);
	        System.out.println("Enter withdrawal:");
	        int b = sc.nextInt();
	        
	       
	        ba.withdraw(b);
	       sc.close();
	    }
	
	}


