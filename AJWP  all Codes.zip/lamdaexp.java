package com.sample.com;

@FunctionalInterface
interface MyInterface {
 void show(int a);

}


public class lamdaexp {

 public static void main(String[] args) {

     
     MyInterface m = (int a) -> {
         System.out.println("Hello " + a);
     };

     
     m.show(10);
 }
}

/*


public void m3(int a)
{ 
sop()
}

(int a)->{
return
}
*/