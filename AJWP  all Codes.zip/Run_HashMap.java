package com.sample.com;

import java.util.HashMap;
 class Students_one {
	int id ;
	
	
	public Students_one(int id)
	{
		this.id=id;
		
	}

}
 
 class Students_two{
	 String name;
	 public Students_two(String name)
	 {
		 this.name=name;
	 }
 }


public class Run_HashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students_one s1=new Students_one(18);
		Students_two ss1=new Students_two("Virat");
		Students_one s2=new Students_one(45);
		Students_two ss2=new Students_two("Rohit");
		
		HashMap<Students_one,Students_two> hm=new HashMap<Students_one,Students_two>();
		
		hm.put(s1,ss1);
		hm.put(s2,ss2);
		System.out.println(" MAP :"+hm);
		
		

	}
	
	

}
