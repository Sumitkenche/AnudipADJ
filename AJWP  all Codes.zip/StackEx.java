package com.sample.com;



public class StackEx {

    int[] arr = new int[4]; 
    int top = -1;

    
    public void push(int a) {
    	
        
         if (top == arr.length - 1) {
            System.out.println("Stack Overflow");
          }
        else {
            top++;
            arr[top] = a;
            System.out.println(a + " pushed to stack");
        }
    }

    
    public void pop() 
    {
        if (top == -1) {
            System.out.println("Stack Underflow");
        } else {
        	System.out.println(arr[top]+ " popped from  the stack");
            top--;
            
        }
    }

    
    public void peek() 
    {
        if (top == -1) {
            System.out.println("Stack is empty");
        } else {
            System.out.println("\n Top element is: " + arr[top]);
        }
    }
    public void isEmpty()
    {
    	if(top==-1)
    	{
    		System.out.println("isEmpty 'TRUE'");
    	}
    	else {
    		System.out.println("isEmpty 'FALSE'");
    	}
    }
    
    

    public static void main(String[] args) {

        StackEx s = new StackEx();

        s.push(22);
        s.push(12);
        s.push(44);
        s.push(9);
       
        s.peek();   

        s.pop();
        s.peek(); 
        s.isEmpty();
        
        
    }
}
