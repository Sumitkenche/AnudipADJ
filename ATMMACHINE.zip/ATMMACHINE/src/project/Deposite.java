package project;



import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Deposite extends JFrame {
	JLabel lb2;
	Deposite()
	{
		setTitle("Withdrawal");
		setSize(300,300);
		
        
        setLayout(null);
        
        
		JLabel lb2=new JLabel("Deposite  successfull");
		
	
		lb2.setBounds(10,10,200,60);
		add(lb2);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}

	public static void main(String[] args) {
		new Deposite();
		

	}

}
