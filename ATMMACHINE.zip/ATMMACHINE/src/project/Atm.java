package project;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class Atm  implements ActionListener{
	
	private JButton b1,b2,b3,b4,b5;
	private JLabel lb1;
	Atm()
	{
		JFrame jf=new JFrame("ATM MACHINE");
		jf.setSize(500,500);

		Color b=new Color(204,255,205); //
		
		jf.getContentPane().setBackground(b);
		jf.setLayout(null);
		lb1=new JLabel("<html><u >STATE BANK OF INDIA</u></html>",JLabel.CENTER);
		Font ft=new Font("arial",Font.BOLD,16);
		lb1.setFont(ft);
		lb1.setForeground(Color.blue);
		
		
		
		
		this.b1=new JButton("Withdraw Cash");
		this.b2=new JButton("Deposite Cash");
		this.b3=new JButton("Check balance");
		this.b4=new JButton("Change pin");
		this.b5=new JButton("Exit");
		
		 Color c=new Color(255,204,255);
		

				b1.setBackground(c);
			    b2.setBackground(c);
			    b3.setBackground(c);
				b4.setBackground(c);
		 Color d=new Color(255,102,0);
		        b5.setBackground(d);
		
					
		
		lb1.setBounds(90,20,300,50);
		
		b1.setBounds(50,100,150,30);
		b2.setBounds(230,100,150,30);
		
		b3.setBounds(50,150,150,30);
		b4.setBounds(230,150,150,30);
		
		b5.setBounds(150,200,150,30);
		
		
		
		jf.add(b1);
		jf.add(b2);
		jf.add(b3);
		jf.add(b4);
		jf.add(b5);
		
		
		jf.add(lb1,BorderLayout.NORTH);
		
	
		b1.addActionListener(new ActionListener() 
		{public void actionPerformed(ActionEvent e) {
			new Withdraw();
		}
		});
		//
		b2.addActionListener(new ActionListener() 
		{public void actionPerformed(ActionEvent e) {
			new Deposite();
		}
		});
		
		//
		b4.addActionListener(new ActionListener() 
		{public void actionPerformed(ActionEvent e) {
			new Changepin();
		}
		});
		//
		b3.addActionListener(new ActionListener() 
		{public void actionPerformed(ActionEvent e) {
			new Balance();
		}
		});
		//
		b5.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        System.exit(0);   // stops JVM
		    }
		});
		
		
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	

	public static void main(String[] args) {
		
	new Atm();
	

	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		
	}
}
	
	

	


