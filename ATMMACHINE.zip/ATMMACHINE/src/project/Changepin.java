package project;



import javax.swing.JFrame;
import javax.swing.JLabel;

public class Changepin extends JFrame {
	JLabel lb2;
	Changepin()
	{
		setTitle("Withdrawal");
		setSize(300,300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        
        
		JLabel lb2=new JLabel("Pin change successfull");
		lb2.setBounds(10,10,180,20);
		add(lb2);
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new Changepin();
		

	}

}
